﻿namespace 화면설계
{
    partial class frmNewEyeTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(355, 294);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 109;
            this.button1.Text = "등록";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(444, 294);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 109;
            this.button2.Text = "취소";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(8, 220);
            this.textBox17.Multiline = true;
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(529, 57);
            this.textBox17.TabIndex = 110;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(501, 23);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(21, 12);
            this.label24.TabIndex = 139;
            this.label24.Text = "RX";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(438, 23);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(43, 12);
            this.label23.TabIndex = 138;
            this.label23.Text = "PRISM";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(217, 23);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(45, 12);
            this.label19.TabIndex = 137;
            this.label19.Text = "원용PD";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(396, 23);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(22, 12);
            this.label22.TabIndex = 136;
            this.label22.Text = "OH";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(331, 23);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(45, 12);
            this.label21.TabIndex = 135;
            this.label21.Text = "근용PD";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(165, 23);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(32, 12);
            this.label18.TabIndex = 134;
            this.label18.Text = "AXIS";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(282, 23);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(29, 12);
            this.label20.TabIndex = 133;
            this.label20.Text = "ADD";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(116, 23);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 12);
            this.label17.TabIndex = 132;
            this.label17.Text = "CYL";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(67, 23);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 131;
            this.label16.Text = "SPH";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label12.Location = new System.Drawing.Point(6, 70);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(22, 12);
            this.label12.TabIndex = 112;
            this.label12.Text = "OD";
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(496, 38);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(41, 21);
            this.textBox42.TabIndex = 129;
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(496, 67);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(41, 21);
            this.textBox43.TabIndex = 128;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(441, 38);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(41, 21);
            this.textBox39.TabIndex = 127;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(441, 67);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(41, 21);
            this.textBox19.TabIndex = 130;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(386, 38);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(41, 21);
            this.textBox38.TabIndex = 126;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(386, 67);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(41, 21);
            this.textBox28.TabIndex = 125;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(56, 38);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(41, 21);
            this.textBox35.TabIndex = 114;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(331, 38);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(41, 21);
            this.textBox34.TabIndex = 124;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(56, 67);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(41, 21);
            this.textBox29.TabIndex = 113;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(111, 38);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(41, 21);
            this.textBox31.TabIndex = 116;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(331, 67);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(41, 21);
            this.textBox32.TabIndex = 123;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(276, 38);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(41, 21);
            this.textBox30.TabIndex = 122;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(111, 67);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(41, 21);
            this.textBox33.TabIndex = 115;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(166, 38);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(41, 21);
            this.textBox27.TabIndex = 118;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(276, 67);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(41, 21);
            this.textBox36.TabIndex = 121;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(221, 38);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(41, 21);
            this.textBox20.TabIndex = 119;
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(166, 67);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(41, 21);
            this.textBox37.TabIndex = 117;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(221, 67);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(41, 21);
            this.textBox40.TabIndex = 120;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label13.Location = new System.Drawing.Point(6, 41);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(22, 12);
            this.label13.TabIndex = 111;
            this.label13.Text = "OS";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(501, 106);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 12);
            this.label1.TabIndex = 168;
            this.label1.Text = "RX";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(438, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 12);
            this.label2.TabIndex = 167;
            this.label2.Text = "PRISM";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(217, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 12);
            this.label3.TabIndex = 166;
            this.label3.Text = "원용PD";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(396, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(22, 12);
            this.label4.TabIndex = 165;
            this.label4.Text = "OH";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(331, 106);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 12);
            this.label5.TabIndex = 164;
            this.label5.Text = "근용PD";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(165, 106);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 12);
            this.label6.TabIndex = 163;
            this.label6.Text = "AXIS";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(282, 106);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 162;
            this.label7.Text = "ADD";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(116, 106);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 161;
            this.label8.Text = "CYL";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(67, 106);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 160;
            this.label9.Text = "SPH";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label10.Location = new System.Drawing.Point(6, 153);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(22, 12);
            this.label10.TabIndex = 141;
            this.label10.Text = "OD";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(496, 121);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(41, 21);
            this.textBox1.TabIndex = 158;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(496, 150);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(41, 21);
            this.textBox2.TabIndex = 157;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(441, 121);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(41, 21);
            this.textBox3.TabIndex = 156;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(441, 150);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(41, 21);
            this.textBox4.TabIndex = 159;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(386, 121);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(41, 21);
            this.textBox5.TabIndex = 155;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(386, 150);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(41, 21);
            this.textBox6.TabIndex = 154;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(56, 121);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(41, 21);
            this.textBox7.TabIndex = 143;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(331, 121);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(41, 21);
            this.textBox8.TabIndex = 153;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(56, 150);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(41, 21);
            this.textBox9.TabIndex = 142;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(111, 121);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(41, 21);
            this.textBox10.TabIndex = 145;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(331, 150);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(41, 21);
            this.textBox11.TabIndex = 152;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(276, 121);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(41, 21);
            this.textBox12.TabIndex = 151;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(111, 150);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(41, 21);
            this.textBox13.TabIndex = 144;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(166, 121);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(41, 21);
            this.textBox14.TabIndex = 147;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(276, 150);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(41, 21);
            this.textBox15.TabIndex = 150;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(221, 121);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(41, 21);
            this.textBox16.TabIndex = 148;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(166, 150);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(41, 21);
            this.textBox18.TabIndex = 146;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(221, 150);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(41, 21);
            this.textBox21.TabIndex = 149;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label11.Location = new System.Drawing.Point(6, 124);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(22, 12);
            this.label11.TabIndex = 140;
            this.label11.Text = "OS";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(29, 205);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 12);
            this.label14.TabIndex = 160;
            this.label14.Text = "메모";
            // 
            // frmNewEyeTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(542, 329);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.textBox42);
            this.Controls.Add(this.textBox43);
            this.Controls.Add(this.textBox39);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox38);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.textBox34);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.textBox40);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "frmNewEyeTest";
            this.Text = "frmNewEyeTest";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
    }
}