﻿namespace 화면설계
{
    partial class frmWorkRecord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.label28 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label29 = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.label30 = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label31 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.label33 = new System.Windows.Forms.Label();
            this.panel26 = new System.Windows.Forms.Panel();
            this.label34 = new System.Windows.Forms.Label();
            this.panel27 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.panel28 = new System.Windows.Forms.Panel();
            this.label36 = new System.Windows.Forms.Label();
            this.panel29 = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.panel30 = new System.Windows.Forms.Panel();
            this.label38 = new System.Windows.Forms.Label();
            this.panel31 = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.panel32 = new System.Windows.Forms.Panel();
            this.label40 = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.label41 = new System.Windows.Forms.Label();
            this.panel34 = new System.Windows.Forms.Panel();
            this.label42 = new System.Windows.Forms.Label();
            this.panel35 = new System.Windows.Forms.Panel();
            this.label43 = new System.Windows.Forms.Label();
            this.panel36 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.panel37 = new System.Windows.Forms.Panel();
            this.label45 = new System.Windows.Forms.Label();
            this.panel38 = new System.Windows.Forms.Panel();
            this.label46 = new System.Windows.Forms.Label();
            this.panel39 = new System.Windows.Forms.Panel();
            this.label47 = new System.Windows.Forms.Label();
            this.panel40 = new System.Windows.Forms.Panel();
            this.label48 = new System.Windows.Forms.Label();
            this.panel41 = new System.Windows.Forms.Panel();
            this.label49 = new System.Windows.Forms.Label();
            this.panel42 = new System.Windows.Forms.Panel();
            this.label50 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.listView1 = new System.Windows.Forms.ListView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button3 = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel40.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel42.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(12, 101);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(70, 70);
            this.panel1.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "27";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(12, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "2020년 10월";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "월";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(88, 101);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(70, 70);
            this.panel2.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "28";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(113, 86);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(17, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "화";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(164, 101);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(70, 70);
            this.panel3.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 6);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(17, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "29";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(189, 86);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(17, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "수";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel4.Controls.Add(this.label8);
            this.panel4.Location = new System.Drawing.Point(240, 101);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(70, 70);
            this.panel4.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(5, 6);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(17, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "30";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(265, 86);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(17, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "목";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel5.Controls.Add(this.label10);
            this.panel5.Location = new System.Drawing.Point(316, 101);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(70, 70);
            this.panel5.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(5, 6);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(11, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "1";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(341, 86);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(17, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "금";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel6.Controls.Add(this.label12);
            this.panel6.Location = new System.Drawing.Point(392, 101);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(70, 70);
            this.panel6.TabIndex = 0;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(5, 6);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(11, 12);
            this.label12.TabIndex = 0;
            this.label12.Text = "2";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(417, 86);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(17, 12);
            this.label13.TabIndex = 0;
            this.label13.Text = "토";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel7.Controls.Add(this.label14);
            this.panel7.Location = new System.Drawing.Point(468, 101);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(70, 70);
            this.panel7.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(5, 6);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(11, 12);
            this.label14.TabIndex = 0;
            this.label14.Text = "1";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(493, 86);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(17, 12);
            this.label15.TabIndex = 0;
            this.label15.Text = "일";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel8.Controls.Add(this.label16);
            this.panel8.Location = new System.Drawing.Point(12, 177);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(70, 70);
            this.panel8.TabIndex = 0;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(5, 6);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(11, 12);
            this.label16.TabIndex = 0;
            this.label16.Text = "1";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel9.Controls.Add(this.label17);
            this.panel9.Location = new System.Drawing.Point(88, 177);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(70, 70);
            this.panel9.TabIndex = 0;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(5, 6);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(11, 12);
            this.label17.TabIndex = 0;
            this.label17.Text = "1";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel10.Controls.Add(this.label18);
            this.panel10.Location = new System.Drawing.Point(164, 177);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(70, 70);
            this.panel10.TabIndex = 0;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(5, 6);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(11, 12);
            this.label18.TabIndex = 0;
            this.label18.Text = "1";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel11.Controls.Add(this.label19);
            this.panel11.Location = new System.Drawing.Point(240, 177);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(70, 70);
            this.panel11.TabIndex = 0;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(5, 6);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(11, 12);
            this.label19.TabIndex = 0;
            this.label19.Text = "1";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel12.Controls.Add(this.label20);
            this.panel12.Location = new System.Drawing.Point(316, 177);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(70, 70);
            this.panel12.TabIndex = 0;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(5, 6);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(11, 12);
            this.label20.TabIndex = 0;
            this.label20.Text = "1";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel13.Controls.Add(this.label21);
            this.panel13.Location = new System.Drawing.Point(392, 177);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(70, 70);
            this.panel13.TabIndex = 0;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(5, 6);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(11, 12);
            this.label21.TabIndex = 0;
            this.label21.Text = "1";
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel14.Controls.Add(this.label22);
            this.panel14.Location = new System.Drawing.Point(468, 177);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(70, 70);
            this.panel14.TabIndex = 0;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(5, 6);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(11, 12);
            this.label22.TabIndex = 0;
            this.label22.Text = "1";
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel15.Controls.Add(this.label23);
            this.panel15.Location = new System.Drawing.Point(12, 253);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(70, 70);
            this.panel15.TabIndex = 0;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(5, 6);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(11, 12);
            this.label23.TabIndex = 0;
            this.label23.Text = "1";
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel16.Controls.Add(this.label24);
            this.panel16.Location = new System.Drawing.Point(88, 253);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(70, 70);
            this.panel16.TabIndex = 0;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(5, 6);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(11, 12);
            this.label24.TabIndex = 0;
            this.label24.Text = "1";
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel17.Controls.Add(this.label25);
            this.panel17.Location = new System.Drawing.Point(164, 253);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(70, 70);
            this.panel17.TabIndex = 0;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(5, 6);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(11, 12);
            this.label25.TabIndex = 0;
            this.label25.Text = "1";
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel18.Controls.Add(this.label26);
            this.panel18.Location = new System.Drawing.Point(240, 253);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(70, 70);
            this.panel18.TabIndex = 0;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(5, 6);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(11, 12);
            this.label26.TabIndex = 0;
            this.label26.Text = "1";
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel19.Controls.Add(this.label27);
            this.panel19.Location = new System.Drawing.Point(316, 253);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(70, 70);
            this.panel19.TabIndex = 0;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(5, 6);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(11, 12);
            this.label27.TabIndex = 0;
            this.label27.Text = "1";
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel20.Controls.Add(this.label28);
            this.panel20.Location = new System.Drawing.Point(392, 253);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(70, 70);
            this.panel20.TabIndex = 0;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(5, 6);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(11, 12);
            this.label28.TabIndex = 0;
            this.label28.Text = "1";
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel21.Controls.Add(this.label29);
            this.panel21.Location = new System.Drawing.Point(468, 253);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(70, 70);
            this.panel21.TabIndex = 0;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(5, 6);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(11, 12);
            this.label29.TabIndex = 0;
            this.label29.Text = "1";
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel22.Controls.Add(this.label30);
            this.panel22.Location = new System.Drawing.Point(12, 329);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(70, 70);
            this.panel22.TabIndex = 0;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(5, 6);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(11, 12);
            this.label30.TabIndex = 0;
            this.label30.Text = "1";
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel23.Controls.Add(this.label31);
            this.panel23.Location = new System.Drawing.Point(88, 329);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(70, 70);
            this.panel23.TabIndex = 0;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(5, 6);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(11, 12);
            this.label31.TabIndex = 0;
            this.label31.Text = "1";
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel24.Controls.Add(this.label32);
            this.panel24.Location = new System.Drawing.Point(164, 329);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(70, 70);
            this.panel24.TabIndex = 0;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(5, 6);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(11, 12);
            this.label32.TabIndex = 0;
            this.label32.Text = "1";
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel25.Controls.Add(this.label33);
            this.panel25.Location = new System.Drawing.Point(240, 329);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(70, 70);
            this.panel25.TabIndex = 0;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(5, 6);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(11, 12);
            this.label33.TabIndex = 0;
            this.label33.Text = "1";
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel26.Controls.Add(this.label34);
            this.panel26.Location = new System.Drawing.Point(316, 329);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(70, 70);
            this.panel26.TabIndex = 0;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(5, 6);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(11, 12);
            this.label34.TabIndex = 0;
            this.label34.Text = "1";
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel27.Controls.Add(this.label35);
            this.panel27.Location = new System.Drawing.Point(392, 329);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(70, 70);
            this.panel27.TabIndex = 0;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(5, 6);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(11, 12);
            this.label35.TabIndex = 0;
            this.label35.Text = "1";
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel28.Controls.Add(this.label36);
            this.panel28.Location = new System.Drawing.Point(468, 329);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(70, 70);
            this.panel28.TabIndex = 0;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(5, 6);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(11, 12);
            this.label36.TabIndex = 0;
            this.label36.Text = "1";
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel29.Controls.Add(this.label37);
            this.panel29.Location = new System.Drawing.Point(12, 405);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(70, 70);
            this.panel29.TabIndex = 0;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(5, 6);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(11, 12);
            this.label37.TabIndex = 0;
            this.label37.Text = "1";
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel30.Controls.Add(this.label38);
            this.panel30.Location = new System.Drawing.Point(88, 405);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(70, 70);
            this.panel30.TabIndex = 0;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(5, 6);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(11, 12);
            this.label38.TabIndex = 0;
            this.label38.Text = "1";
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel31.Controls.Add(this.label39);
            this.panel31.Location = new System.Drawing.Point(164, 405);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(70, 70);
            this.panel31.TabIndex = 0;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(5, 6);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(11, 12);
            this.label39.TabIndex = 0;
            this.label39.Text = "1";
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel32.Controls.Add(this.label40);
            this.panel32.Location = new System.Drawing.Point(240, 405);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(70, 70);
            this.panel32.TabIndex = 0;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(5, 6);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(11, 12);
            this.label40.TabIndex = 0;
            this.label40.Text = "1";
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel33.Controls.Add(this.label41);
            this.panel33.Location = new System.Drawing.Point(316, 405);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(70, 70);
            this.panel33.TabIndex = 0;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(5, 6);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(11, 12);
            this.label41.TabIndex = 0;
            this.label41.Text = "1";
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel34.Controls.Add(this.label42);
            this.panel34.Location = new System.Drawing.Point(392, 405);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(70, 70);
            this.panel34.TabIndex = 0;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(5, 6);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(11, 12);
            this.label42.TabIndex = 0;
            this.label42.Text = "1";
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel35.Controls.Add(this.label43);
            this.panel35.Location = new System.Drawing.Point(468, 405);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(70, 70);
            this.panel35.TabIndex = 0;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(5, 6);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(17, 12);
            this.label43.TabIndex = 0;
            this.label43.Text = "31";
            // 
            // panel36
            // 
            this.panel36.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel36.Controls.Add(this.label44);
            this.panel36.Location = new System.Drawing.Point(12, 481);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(70, 70);
            this.panel36.TabIndex = 0;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(5, 6);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(11, 12);
            this.label44.TabIndex = 0;
            this.label44.Text = "1";
            // 
            // panel37
            // 
            this.panel37.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel37.Controls.Add(this.label45);
            this.panel37.Location = new System.Drawing.Point(88, 481);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(70, 70);
            this.panel37.TabIndex = 0;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(5, 6);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(11, 12);
            this.label45.TabIndex = 0;
            this.label45.Text = "2";
            // 
            // panel38
            // 
            this.panel38.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel38.Controls.Add(this.label46);
            this.panel38.Location = new System.Drawing.Point(164, 481);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(70, 70);
            this.panel38.TabIndex = 0;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(5, 6);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(11, 12);
            this.label46.TabIndex = 0;
            this.label46.Text = "1";
            // 
            // panel39
            // 
            this.panel39.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel39.Controls.Add(this.label47);
            this.panel39.Location = new System.Drawing.Point(240, 481);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(70, 70);
            this.panel39.TabIndex = 0;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(5, 6);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(11, 12);
            this.label47.TabIndex = 0;
            this.label47.Text = "1";
            // 
            // panel40
            // 
            this.panel40.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel40.Controls.Add(this.label48);
            this.panel40.Location = new System.Drawing.Point(316, 481);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(70, 70);
            this.panel40.TabIndex = 0;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(5, 6);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(11, 12);
            this.label48.TabIndex = 0;
            this.label48.Text = "1";
            // 
            // panel41
            // 
            this.panel41.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel41.Controls.Add(this.label49);
            this.panel41.Location = new System.Drawing.Point(392, 481);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(70, 70);
            this.panel41.TabIndex = 0;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(5, 6);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(11, 12);
            this.label49.TabIndex = 0;
            this.label49.Text = "1";
            // 
            // panel42
            // 
            this.panel42.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel42.Controls.Add(this.label50);
            this.panel42.Location = new System.Drawing.Point(468, 481);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(70, 70);
            this.panel42.TabIndex = 0;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(5, 6);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(11, 12);
            this.label50.TabIndex = 0;
            this.label50.Text = "1";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(455, 26);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(83, 21);
            this.dateTimePicker1.TabIndex = 2;
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(12, 572);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(222, 97);
            this.listView1.TabIndex = 3;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(241, 646);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "삭제";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(241, 598);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(92, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "추가";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(241, 572);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(91, 20);
            this.comboBox1.TabIndex = 5;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(446, 626);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(92, 43);
            this.button3.TabIndex = 4;
            this.button3.Text = "종료";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // frmWorkRecord
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(552, 681);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel42);
            this.Controls.Add(this.panel35);
            this.Controls.Add(this.panel28);
            this.Controls.Add(this.panel21);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel41);
            this.Controls.Add(this.panel34);
            this.Controls.Add(this.panel27);
            this.Controls.Add(this.panel20);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel40);
            this.Controls.Add(this.panel33);
            this.Controls.Add(this.panel26);
            this.Controls.Add(this.panel19);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel39);
            this.Controls.Add(this.panel32);
            this.Controls.Add(this.panel25);
            this.Controls.Add(this.panel18);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel38);
            this.Controls.Add(this.panel31);
            this.Controls.Add(this.panel24);
            this.Controls.Add(this.panel17);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel37);
            this.Controls.Add(this.panel30);
            this.Controls.Add(this.panel23);
            this.Controls.Add(this.panel16);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel36);
            this.Controls.Add(this.panel29);
            this.Controls.Add(this.panel22);
            this.Controls.Add(this.panel15);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel1);
            this.Name = "frmWorkRecord";
            this.Text = "WorkRecord";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.panel36.ResumeLayout(false);
            this.panel36.PerformLayout();
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.panel38.ResumeLayout(false);
            this.panel38.PerformLayout();
            this.panel39.ResumeLayout(false);
            this.panel39.PerformLayout();
            this.panel40.ResumeLayout(false);
            this.panel40.PerformLayout();
            this.panel41.ResumeLayout(false);
            this.panel41.PerformLayout();
            this.panel42.ResumeLayout(false);
            this.panel42.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}